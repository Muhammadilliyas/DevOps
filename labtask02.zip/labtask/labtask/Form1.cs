﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace labtask
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int sec = 60;
        private void timerlabel_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if(sec > 0)
            {
                sec = sec - 1;
                timerlabel.Text = sec + " Seconds Left!";
            }
            else
            {
                timer.Stop();
                timerlabel.Text = "Time is finished!!";
            }
        }

        private void reset_button_Click(object sender, EventArgs e)
        {
            timer.Stop();
            sec = 60;
            timerlabel.Text = sec + " Seconds Left!";
        }

        private void Stop_button_Click(object sender, EventArgs e)
        {
            timer.Stop();
        }

        private void start_button_Click(object sender, EventArgs e)
        {
            timer.Start();
        }

        private void plus_button_Click(object sender, EventArgs e)
        {
            sec = sec + 5;
            timerlabel.Text = sec.ToString() + " Seconds Left!";
        }

        private void minus_button_Click(object sender, EventArgs e)
        {
            sec = sec - 5;
            timerlabel.Text = sec.ToString() + " Seconds Left!";
        }
    }
} 
